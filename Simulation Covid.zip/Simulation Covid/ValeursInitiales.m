function y = ValeursInitiales()
%retourne une colonne des valeurs initiales
format long
Istar=12000;B=800;N0=67*10^6;I0=0.01*Istar;p=0.9;
y=zeros(10,1);
y(1,1)=N0-I0; y(4,1)=p*I0;y(8,1)=(1-p)*I0; 
end