function [t,d] = Solveursyseqdiff1(Y0,F,Inter,Nh)
%-----------Entr�es
% Ce programme permet de r�soudre un syst�me d'�quations diff�rentielles
% par la m�thode de Rung-Kutta4
% Nh est le nombre de subdivision
% F est le vecteur colonne contenant les fonctions qui d�finissent les seconds
% membres
% Y0 vecteur colonne contenant les valeurs initiales
%-----------Sorties
%-----------le vecteur de t et la matrice Y contenant sur chaque ligne les diff�rentes valeurs prises par chaque inconnue.
format long
%colonne des valeurs initiales
y0=Y0();

t0=Inter(1);
tf=Inter(2);

N=size(y0,1);
h=(tf-t0)/Nh;
Y=zeros(N,Nh+1);
Y(:,1)=y0;
t(1)=t0;
for i=0:Nh-1
    K11=h*F(t0,y0);
    
    K21=h*F(t0+h/2,y0+K11/2);
    
    K31=h*F(t0+h/2,y0+K21/2);
    
    K41=h*F(t0+h,y0+K31);
    
    y0=y0+(1/6)*(K11+2*K21+2*K31+K41);
    t0=t0+h;
    Y(:,i+2)=y0;
    t(i+2)=t0;
end
d=Y;
end

