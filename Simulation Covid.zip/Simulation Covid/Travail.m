% Ce programme permet de prendre en exemple et de r�soudre un syst�me d'�quations diff�rentielles
% par la m�thode de Rung-Kutta4
format long
fprintf('Entrez l_intervalle de t:\n');
Inter(1)=input('t0=');
Inter(2)=input('tf=');
Nh=input('Entrez le nombre de subdivisions:');
[t,Y] = Solveursyseqdiff1(@ValeursInitiales,@Fonction_sys,Inter,Nh);
plot(t,Y(8,:),'g');
ylabel('Is');
xlabel('t');
hold on
grid on