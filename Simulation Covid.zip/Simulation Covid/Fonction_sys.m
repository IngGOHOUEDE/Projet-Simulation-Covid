function Y = Fonction_sys(t,y)
R0=2.5;p=0.9;psi=0.2;c=0.1;nu=2;epsi=1/4.2;sigma=1;teta=0.15;gammam=1/17;gammas=1/20;mu=10^(-5);Istar=12000;B=800;N0=67*10^6;I0=0.01*Istar;
alphamin=gammas*teta/(1-teta);
alphamax=2*alphamin;
betaA=(R0*gammam*sigma/(N0-I0))*(alphamin+gammas)/((gammam+p*sigma)*(alphamin+gammas)+psi*gammam*sigma*(1-p));
betaI=betaA;
lambda=(1-c)*(betaA*(y(7,1)+y(3,1))+betaI*(y(4,1)+psi*y(8,1)));
E=y(6,1)+y(2,1);A=y(7,1)+y(3,1);I=y(8,1)+y(4,1);R=y(9,1)+y(5,1);
N=y(1,1)+E+A+I+R;
Y=zeros(9,1);
Y(1,1) = -lambda*y(1,1)-Mu(y(8,1))*y(1,1);
Y(2,1) = p*lambda*y(1,1)-epsi*y(2,1)-Mu(y(8,1))*y(2,1)+p*nu;
Y(3,1) = epsi*y(2,1)-sigma*y(3,1)-Mu(y(8,1))*y(3,1);
Y(4,1) = sigma*y(3,1)-(gammam+Mu(y(8,1)))*y(4,1);
Y(5,1) = gammam*y(4,1)-Mu(y(8,1))*y(5,1);
Y(6,1) = (1-p)*lambda*y(1,1)-epsi*y(6,1)-Mu(y(8,1))*y(6,1)+(1-p)*nu;
Y(7,1) = epsi*y(6,1)-sigma*y(7,1)-Mu(y(8,1))*y(7,1);
Y(8,1) = sigma*y(7,1)-(gammas+Mu(y(8,1))+alpha(y(8,1)))*y(8,1);
Y(9,1) = gammas*y(8,1)-Mu(y(8,1))*y(9,1);
Y(10,1)=alpha(y(8,1))*y(8,1)+Mu(y(8,1))*N;

end