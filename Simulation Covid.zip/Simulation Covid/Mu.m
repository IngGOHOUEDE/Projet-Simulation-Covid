function y= Mu(Is)
%Retourne mu
Istar=12000;
mu=10^(-5);
if Is<Istar
    y=0;
else 
    y=mu;
end
end