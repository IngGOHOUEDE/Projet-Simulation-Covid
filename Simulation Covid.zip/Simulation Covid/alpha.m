function alpha= alpha(Is)
%Retourne alpha
Istar=12000;teta=0.15;gammas=1/20;alphamin=gammas*teta/(1-teta);
alphamax=2*alphamin;
if Is<Istar
    alpha=alphamin;
else 
    alpha=alphamax;
end
end